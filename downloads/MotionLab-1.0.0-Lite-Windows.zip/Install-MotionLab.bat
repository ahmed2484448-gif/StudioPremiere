@echo off
rem MotionLab installer - double-click to install into Premiere Pro (Windows)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-MotionLab.ps1"
