﻿# MotionLab installer for Windows (no ZXP Installer needed).
# Extracts MotionLab.zxp (a signed zip) into the per-user CEP extensions
# folder and turns on PlayerDebugMode for CSXS 9-12 so every Premiere version loads it.
# Your saved data (templates, presets, Motion DNA, brand kits) lives in
# %APPDATA%\MotionStoryBuilder and is NOT touched.
# Usage: double-click Install-MotionLab.bat  (or: powershell -File Install-MotionLab.ps1 [-Dest <folder>])
param([string]$Dest = "", [switch]$NoRegistry)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

try {
    $zxp = Get-ChildItem -LiteralPath $here -Filter '*.zxp' | Select-Object -First 1
    if (-not $zxp) { throw "MotionLab.zxp was not found next to this installer. Extract the whole zip first." }
    if ($zxp.Length -lt 200000) { throw "MotionLab.zxp looks incomplete ($($zxp.Length) bytes). Download it again." }

    if (-not $Dest) { $Dest = Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.ahmedamer.motionstory' }

    Write-Host "Installing MotionLab..." -ForegroundColor Cyan
    if (Test-Path -LiteralPath $Dest) {
        $item = Get-Item -LiteralPath $Dest -Force
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
            # A developer link (junction): remove ONLY the link, never the folder it points to
            [System.IO.Directory]::Delete($Dest, $false)
        } else {
            Remove-Item -LiteralPath $Dest -Recurse -Force
        }
    }
    New-Item -ItemType Directory -Force -Path $Dest | Out-Null

    # A .zxp is a zip archive - copy it with a .zip name and extract it
    $tmp = Join-Path $env:TEMP ('msb_' + [guid]::NewGuid().ToString('N') + '.zip')
    Copy-Item -LiteralPath $zxp.FullName -Destination $tmp
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($tmp, $Dest)
    Remove-Item -LiteralPath $tmp -Force

    if (-not (Test-Path -LiteralPath (Join-Path $Dest 'CSXS\manifest.xml'))) { throw "The package is damaged (manifest missing)." }

    # Allow the extension to load in every CEP runtime Premiere may use
    if (-not $NoRegistry) { foreach ($v in 9..12) {
        $key = "HKCU:\Software\Adobe\CSXS.$v"
        if (-not (Test-Path $key)) { New-Item -Path $key -Force | Out-Null }
        Set-ItemProperty -Path $key -Name 'PlayerDebugMode' -Value '1' -Type String
    } }

    # An older copy installed for ALL users (ZXP Installer / ExManCmd) has the same ID and Premiere
    # loads it instead of this one. Removed when this window runs as administrator, otherwise explained.
    $sysDirs = @((Join-Path ${env:ProgramFiles(x86)} 'Common Files\Adobe\CEP\extensions\com.ahmedamer.motionstory'),
                 (Join-Path $env:ProgramFiles 'Common Files\Adobe\CEP\extensions\com.ahmedamer.motionstory')) | Select-Object -Unique
    foreach ($old in $sysDirs) {
        if ($old -and (Test-Path -LiteralPath $old) -and ($old -ne $Dest)) {
            try { Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction Stop; Write-Host "Removed an older MotionLab copy: $old" -ForegroundColor Yellow }
            catch {
                Write-Host ""
                Write-Host "WARNING: an older MotionLab is installed for all users and Premiere will load it instead:" -ForegroundColor Yellow
                Write-Host "  $old" -ForegroundColor Yellow
                Write-Host "  Run Install-MotionLab.bat again with right-click > Run as administrator to remove it," -ForegroundColor Yellow
                Write-Host "  or delete that folder yourself, then restart Premiere Pro." -ForegroundColor Yellow
            }
        }
    }

    Write-Host ""
    Write-Host "MotionLab installed:" -ForegroundColor Green
    Write-Host "  $Dest"
    Write-Host ""
    Write-Host "1. Close Premiere Pro completely and open it again."
    Write-Host "2. Open: Window > Extensions (Legacy) > MotionLab"
    Write-Host "   (older versions: Window > Extensions > MotionLab)"
    $code = 0
}
catch {
    Write-Host ""
    Write-Host ("Installation failed: " + $_.Exception.Message) -ForegroundColor Red
    $code = 1
}
Write-Host ""
if (-not $env:MSB_NO_PAUSE) { Read-Host "Press Enter to close" | Out-Null }
exit $code
